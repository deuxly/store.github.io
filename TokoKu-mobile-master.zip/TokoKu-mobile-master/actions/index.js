export const login = (user) => ({
    type: 'LOGIN',
    user
})
export const logout = (user) => ({
    type: 'LOGOUT',
    user
})